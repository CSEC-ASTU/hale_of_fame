var User = require('./users');
var Admin = require('./admins');
var Token = require('./token');

module.exports = {
    User,
    Admin,
    Token,
}